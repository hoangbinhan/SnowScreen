const canvas = document.getElementById('snow-canvas');
if (canvas) {
    const ctx = canvas.getContext('2d');

    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
    });

    class Flake {
        constructor() {
            this.reset();
        }

        reset() {
            this.x = Math.random() * width;
            this.y = Math.random() * -height;
            this.radius = Math.random() * 3 + 1;
            this.speed = Math.random() * 1.2 + 0.8;
            this.wind = Math.random() * 0.8 - 0.4;
            this.opacity = Math.random() * 0.7 + 0.3;
        }

        update() {
            this.y += this.speed;
            this.x += this.wind + Math.sin(this.y * 0.01) * 0.3;

            if (this.y > height) {
                this.reset();
                this.y = 0;
            }
        }

        draw() {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(224, 247, 250, ${this.opacity})`;
            ctx.shadowBlur = 6;
            ctx.shadowColor = 'rgba(0, 229, 255, 0.8)';
            ctx.fill();
        }
    }

    const flakes = Array.from({ length: 60 }, () => new Flake());

    function animate() {
        ctx.clearRect(0, 0, width, height);
        flakes.forEach(flake => {
            flake.update();
            flake.draw();
        });
        requestAnimationFrame(animate);
    }

    animate();
}
